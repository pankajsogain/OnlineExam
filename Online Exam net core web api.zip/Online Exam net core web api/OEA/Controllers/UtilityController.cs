﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using OEA.Models;

namespace OEA.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UtilityController : ControllerBase
    {
        private readonly OeaContext _context;
        public UtilityController(OeaContext context )
        {
            _context = context;
        }

        // GET: api/<UtilityController>
        [HttpGet("GetCountries")]
        public IEnumerable<Countries> GetCountries()
        {
            return _context.Countries.ToList();
        }
        [HttpGet("GetStatesByCountryId")]
        public IEnumerable<States> GetStatesByCountryId(int countryId)
        {
            var states=_context.States.Where(x=>x.CountryId== countryId);
            return states;
        }
        
        [HttpGet("GetCitiesByStateId")]
        public IEnumerable<Cities> GetCitiesByStateId(int stateId)
        {
            var cities = _context.Cities.Where(x => x.StateId == stateId);
            return cities;
        }
        [HttpGet("ValidateEmail")]
        public bool ValidateEmail(string Email)
        {
          return _context.Customeraccount.Any(x => x.EmailId == Email);            
        }
    }
}

﻿using System;
using System.Collections.Generic;

namespace OEA.Models
{
    public partial class Customeraccount
    {
        public int CustId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string EmailId { get; set; }
        public string Password { get; set; }
        public string PhoneNumber { get; set; }
        public int? Country { get; set; }
        public int? State { get; set; }
        public int? City { get; set; }
        public byte? TandC { get; set; }
    }
}

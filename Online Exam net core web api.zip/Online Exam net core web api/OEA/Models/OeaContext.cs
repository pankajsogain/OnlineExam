﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace OEA.Models
{
    public partial class OeaContext : DbContext
    {
        public OeaContext()
        {
        }

        public OeaContext(DbContextOptions<OeaContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Assignedtest> Assignedtest { get; set; }
        public virtual DbSet<Choices> Choices { get; set; }
        public virtual DbSet<Cities> Cities { get; set; }
        public virtual DbSet<Countries> Countries { get; set; }
        public virtual DbSet<Customeraccount> Customeraccount { get; set; }
        public virtual DbSet<Customerrole> Customerrole { get; set; }
        public virtual DbSet<Questions> Questions { get; set; }
        public virtual DbSet<Rolemaster> Rolemaster { get; set; }
        public virtual DbSet<Simtest> Simtest { get; set; }
        public virtual DbSet<States> States { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {

                optionsBuilder.UseMySQL("server=127.0.0.1;user id=root;persistsecurityinfo=True;database=oea;password=Pankaj1@()");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Assignedtest>(entity =>
            {
                entity.ToTable("assignedtest");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.Percentage).HasColumnType("decimal(10,0)");
            });

            modelBuilder.Entity<Choices>(entity =>
            {
                entity.HasKey(e => e.ChoiceId)
                    .HasName("PRIMARY");

                entity.ToTable("choices");

                entity.Property(e => e.Answer)
                    .HasMaxLength(45)
                    .IsUnicode(false);

                entity.Property(e => e.ChoiceFour)
                    .HasMaxLength(45)
                    .IsUnicode(false);

                entity.Property(e => e.ChoiceOne)
                    .HasMaxLength(45)
                    .IsUnicode(false);

                entity.Property(e => e.ChoiceThree)
                    .HasMaxLength(45)
                    .IsUnicode(false);

                entity.Property(e => e.ChoiceTwo)
                    .HasMaxLength(45)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Cities>(entity =>
            {
                entity.ToTable("cities");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasColumnName("name")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.StateId).HasColumnName("state_id");
            });

            modelBuilder.Entity<Countries>(entity =>
            {
                entity.ToTable("countries");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasColumnName("name")
                    .HasMaxLength(150)
                    .IsUnicode(false);

                entity.Property(e => e.Sortname)
                    .IsRequired()
                    .HasColumnName("sortname")
                    .HasMaxLength(3)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Customeraccount>(entity =>
            {
                entity.HasKey(e => e.CustId)
                    .HasName("PRIMARY");

                entity.ToTable("customeraccount");

                entity.Property(e => e.EmailId)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FirstName)
                    .HasMaxLength(25)
                    .IsUnicode(false);

                entity.Property(e => e.LastName)
                    .HasMaxLength(25)
                    .IsUnicode(false);

                entity.Property(e => e.Password)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.PhoneNumber)
                    .HasMaxLength(45)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Customerrole>(entity =>
            {
                entity.ToTable("customerrole");

                entity.Property(e => e.RoleName)
                    .HasMaxLength(45)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Questions>(entity =>
            {
                entity.HasKey(e => e.IdQuestions)
                    .HasName("PRIMARY");

                entity.ToTable("questions");

                entity.Property(e => e.IdQuestions).HasColumnName("idQuestions");

                entity.Property(e => e.CorrectAnswer)
                    .HasMaxLength(45)
                    .IsUnicode(false);

                entity.Property(e => e.Question)
                    .HasMaxLength(400)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Rolemaster>(entity =>
            {
                entity.HasKey(e => e.RoleId)
                    .HasName("PRIMARY");

                entity.ToTable("rolemaster");

                entity.Property(e => e.RoleName)
                    .HasMaxLength(45)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Simtest>(entity =>
            {
                entity.HasKey(e => e.SimTestNumber)
                    .HasName("PRIMARY");

                entity.ToTable("simtest");

                entity.Property(e => e.CustId)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Percentage).HasColumnType("decimal(10,0)");

                entity.Property(e => e.TestName)
                    .HasMaxLength(45)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<States>(entity =>
            {
                entity.ToTable("states");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.CountryId)
                    .HasColumnName("country_id")
                    .HasDefaultValueSql("'1'");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasColumnName("name")
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}

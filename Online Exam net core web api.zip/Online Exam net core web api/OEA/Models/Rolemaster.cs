﻿using System;
using System.Collections.Generic;

namespace OEA.Models
{
    public partial class Rolemaster
    {
        public int RoleId { get; set; }
        public string RoleName { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;

namespace OEA.Models
{
    public partial class Simtest
    {
        public int SimTestNumber { get; set; }
        public string TestName { get; set; }
        public int? Duration { get; set; }
        public decimal? Percentage { get; set; }
        public int? NoofQuestions { get; set; }
        public string CustId { get; set; }
    }
}

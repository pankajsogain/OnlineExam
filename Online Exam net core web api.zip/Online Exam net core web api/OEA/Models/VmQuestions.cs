﻿using System.Collections.Generic;

namespace OEA.Models
{
    public class VmQuestions
    {
        public Simtest SimTest { get; set; }
        public List<Questionwithchoice> Questionwithchoices { get; set; }
    }
}

﻿

namespace OnlineExaminationApps.Models
{
    public class Questionwithchoice
    {
        public Questions Questions { get; set; }
        public Choices Choices { get; set; }

    }
}
